package fr.nsenave.gameslibrary.gameslibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamesLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
